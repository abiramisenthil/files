﻿using InchcapeWebApi.Data;
using InchcapeWebApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace newWepApi.Controllers
{
	
	public class BaseController : Controller
	{
		protected readonly ApplicationDbContext _dbContext;

		public BaseController(ApplicationDbContext dbContext)
		{
			_dbContext = dbContext;
		}

		protected async Task<VehicleDetail> GetVehicleMakeInfo(Guid Id, String Name)
		{

			var record = await _dbContext.VehicleDetails
					.FirstOrDefaultAsync(f => (Id != Guid.Empty && f.id == Id) || (!string.IsNullOrEmpty(Name) && f.Model == Name));
			if (record != null)
				return record;


			return null;
		}

	
	}
}
