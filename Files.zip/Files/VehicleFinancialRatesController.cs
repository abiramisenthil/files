﻿using InchcapeWebApi.Data;
using InchcapeWebApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using newWepApi.Controllers;
using static InchcapeWebApi.Enums.InchcapeEnums;

namespace InchcapeWebApi.Controllers
{
	[ApiController]
	[Route("api/[controller]")]
	public class VehicleFinancialRatesController : BaseController
	{
		public VehicleFinancialRatesController(ApplicationDbContext dbContext) : base(dbContext)
		{

		}

		[HttpGet]
		public IActionResult GetVehicleFinancialRates()
		{
			var result = _dbContext.VehicleDetails.ToList();

			if (result.Count == 0)
			{
				return NotFound();
			}
			return Ok(result);
		}

		[HttpPost]
		public async Task<IActionResult> AddVehicleFinancialRates(VehicleDetail addvehicleRequest)
		{
			var newvehicleDetail = new VehicleDetail()
			{
				id = Guid.NewGuid(),
				Model = addvehicleRequest.Model,
				VehicleType = addvehicleRequest.VehicleType,
				FinanceType = addvehicleRequest.FinanceType,
				ZeroToThreeMonths = addvehicleRequest.ZeroToThreeMonths,
				ThreeToSixMonths = addvehicleRequest.ThreeToSixMonths,
				SixToTwelve = addvehicleRequest.SixToTwelve,
				TwelvePlus = addvehicleRequest.TwelvePlus
			};
			await _dbContext.VehicleDetails.AddAsync(newvehicleDetail);
			await _dbContext.SaveChangesAsync();

			return Ok(newvehicleDetail);
		}

		[HttpPut]
		[Route("{id:guid}")]
		public async Task<IActionResult> SaveVehicleFinancialRates([FromRoute] Guid id, VehicleDetail updateVehicleRequest)
		{
			var vehicleDetail = await _dbContext.VehicleDetails.FindAsync(id);
			if (vehicleDetail != null)
			{
				vehicleDetail.Model = updateVehicleRequest.Model;
				vehicleDetail.VehicleType = updateVehicleRequest.VehicleType;
				vehicleDetail.FinanceType = updateVehicleRequest.FinanceType;
				vehicleDetail.ZeroToThreeMonths = updateVehicleRequest.ZeroToThreeMonths;
				vehicleDetail.ThreeToSixMonths = updateVehicleRequest.ThreeToSixMonths;
				vehicleDetail.SixToTwelve = updateVehicleRequest.SixToTwelve;
				vehicleDetail.TwelvePlus = updateVehicleRequest.TwelvePlus;

				await _dbContext.SaveChangesAsync();

				return Ok(vehicleDetail);
			}
			return NotFound();
		}

		[HttpPost]
		public async Task<IActionResult> AddMake(VehicleDetail addvehicleRequest)
		{
			//TODO: Add all model validation before calling
			var op = await InsertOrUpdateVehicleMake(Guid.Empty, addvehicleRequest.Model);

			//If Required add custom Model and send the info back to User
			return Ok(op);
		}

		[HttpPost]
		public async Task<IActionResult> UpdateMake(VehicleDetail addvehicleRequest)
		{
			//TODO: Add all model validation before calling
			var op = await InsertOrUpdateVehicleMake(addvehicleRequest.id, string.Empty, addvehicleRequest.Model);

			//If Required add custom Model and send the info back to User
			return Ok(op);
		}


		protected async Task<VehicleDetail> InsertOrUpdateVehicleMake(Guid Id, String Name, string newName = "")
		{
			//Name will be null when we call this method for Update Purpose

			var isExists = await GetVehicleMakeInfo(Id, Name);
			if (isExists == null)
			{
				var newvehicleDetail = new VehicleDetail()
				{
					id = Guid.NewGuid(),
					Model = Name
				};
				await _dbContext.VehicleDetails.AddAsync(newvehicleDetail);
				await _dbContext.SaveChangesAsync();
				return newvehicleDetail;
			}
			else if (Id != Guid.Empty && !string.IsNullOrEmpty(newName))
			{
				// Write logic to Update the Existing Record. and then return the updated record.

			}

			return isExists;
		}
	}
}

